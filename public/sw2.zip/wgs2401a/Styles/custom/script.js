


// ----------------------------------
// ----- getVarHref -----
// ----------------------------------
    function getVarHref (nomVariable)
    {
	    var infos = location.href.substring(location.href.indexOf("?")+1, location.href.length)+"&";
	    if (infos.indexOf("#")!=-1)
		    infos = infos.substring(0,infos.indexOf("#"))+"&";
	    var variable=0;
	    {
		    nomVariable = nomVariable + "=";
		    var taille = nomVariable.length;
		    if (infos.indexOf(nomVariable)!=-1)
			    variable = infos.substring(infos.indexOf(nomVariable)+taille,infos.length).substring(0,infos.substring(infos.indexOf(nomVariable)+taille,infos.length).indexOf("&"));
	    }
	    return variable;
    }
