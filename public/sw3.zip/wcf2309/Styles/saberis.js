﻿/* Copyright (C) 2011  Saberis Inc.

    Some of the JavaScript code in this page is the property of Saberis Inc.
	Not to be used or distributed without the written permission of Saberis Inc.
	Some code was modified by Saberis Inc. for 2020 Global Option validation
	Visit www.saberis.com for info on 2020 integration with ERP, POS and Accounting systems
	The code is distributed WITHOUT ANY WARRANTY.

*
* Doug Syme at Saberis added the following:
* Switch coding to hide menues to facilitate Global option validation
* External CSS file for easy style changes
* External js for most java scripts

*/
/* The original Switch Menu Script is from the sources indicated below:
***********************************************
* Switch Menu script- by Martial B of http://getElementById.com/
* Modified by Dynamic Drive for format & NS4/IE4 compatibility
* Visit http://www.dynamicdrive.com/ for full source code
*****************************************************************
*
*/

function OnChange(value)
   {
      parent.returnValue=value
      parent.close();
   }


function onloadfunction881(){
if (persistmenu=="yes"){
var cookiename=(persisttype=="sitewide")? "switchmenu881" : window.location.pathname
var cookievalue=get_cookie(cookiename)
if ((cookievalue!="") && (cookievalue!='sub9' ))
document.getElementById(cookievalue).style.display="block"
}
setarrow881()
}

 
function okButtonClick881(id) {  
 	setDoorStyle() ;    
 	parent.returnValue=id      ;
    parent.close();   
   }

function switchmenu881(obj){
var menunumber = obj
	if(document.getElementById){
	var el = document.getElementById(obj);
	var ar = document.getElementById("masterdiv").getElementsByTagName("span"); //DynamicDrive.com change
	
	if(el.style.display != "block"){ //DynamicDrive.com change
			for (var i=0; i<ar.length; i++){
				if (ar[i].className=="submenu") //DynamicDrive.com change
				ar[i].style.display = "none" ;
		}
			el.style.display = "block";
			var test ="block" ;
		}else{
			el.style.display = "none";
			var test ="none" ;
		}
	}
 switch (menunumber ) {
  case 'sub1': 
  	
	if(el.style.display == "block"){
   			document.getElementById('Arrow1').innerHTML ="&#9660";
 	}else{
	 	document.getElementById('Arrow1').innerHTML ="&#9658";
	 
  	 }
   	  document.getElementById('Arrow2').innerHTML ="&#9658";
  	  document.getElementById('Arrow3').innerHTML ="&#9658";
  	  document.getElementById('Arrow4').innerHTML ="&#9658";
  	  document.getElementById('Arrow5').innerHTML ="&#9658";
  	  break;

  case 'sub2': 
	
	if(el.style.display == "block"){
   			document.getElementById('Arrow2').innerHTML ="&#9660";
 	}else{
	 	document.getElementById('Arrow2').innerHTML ="&#9658";
  	 }
  	  document.getElementById('Arrow1').innerHTML ="&#9658";
  	  document.getElementById('Arrow3').innerHTML ="&#9658";
  	  document.getElementById('Arrow4').innerHTML ="&#9658";
  	  document.getElementById('Arrow5').innerHTML ="&#9658";
  	  break;
 case 'sub3': 
	
	if(el.style.display == "block"){
	
 		document.getElementById('Arrow3').innerHTML ="&#9660";
 	}else{
 		document.getElementById('Arrow3').innerHTML ="&#9658";
  	 }
  	  document.getElementById('Arrow1').innerHTML ="&#9658";
  	  document.getElementById('Arrow2').innerHTML ="&#9658";
  	  document.getElementById('Arrow4').innerHTML ="&#9658";
  	  document.getElementById('Arrow5').innerHTML ="&#9658";
  	  break;
case 'sub4': 
	
	if(el.style.display == "block"){
	
 		document.getElementById('Arrow4').innerHTML ="&#9660";
 	}else{
      document.getElementById('Arrow4').innerHTML ="&#9658";
  	 }
  	  document.getElementById('Arrow1').innerHTML ="&#9658";
  	  document.getElementById('Arrow2').innerHTML ="&#9658";
  	  document.getElementById('Arrow3').innerHTML ="&#9658";
  	  document.getElementById('Arrow5').innerHTML ="&#9658";
  	  break;
case 'sub5': 
	
	if(el.style.display == "block"){
	
 		document.getElementById('Arrow5').innerHTML ="&#9660";
 	}else{
      document.getElementById('Arrow5').innerHTML ="&#9658";
  	 }
  	  document.getElementById('Arrow1').innerHTML ="&#9658";
  	  document.getElementById('Arrow2').innerHTML ="&#9658";
  	  document.getElementById('Arrow3').innerHTML ="&#9658";
  	  document.getElementById('Arrow4').innerHTML ="&#9658";
  	  break;
}
}
function okButtonClick882(id) {  
   	  parent.returnValue=id      
      parent.close();   
   }

function okButtonClick828(id) {  
   	  set828() ;
      parent.returnValue=id      
      parent.close();   
   }


function onloadfunction828()
{
if (persistmenu=="yes"){
var cookiename=(persisttype=="sitewide")? "switchmenu881" : window.location.pathname
var cookievalue=get_cookie(cookiename)
if (cookievalue!="")
document.getElementById(cookievalue).style.display="block"
}
switch (cookievalue) {
  case 'sub1': 
	document.getElementById('main2').style.display="none"
	document.getElementById('main3').style.display="none"
	document.getElementById('main4').style.display="none"
	document.getElementById('main5').style.display="none"
	document.getElementById('main6').style.display="none"
	document.getElementById('main7').style.display="none"
    	document.getElementById('main8').style.display="none"
    	document.getElementById('main9').style.display="none"
    break;
  case 'sub2': 
	document.getElementById('main1').style.display="none"
	document.getElementById('main3').style.display="none"
	document.getElementById('main4').style.display="none"
	document.getElementById('main5').style.display="none"
	document.getElementById('main6').style.display="none"
	document.getElementById('main7').style.display="none"
	document.getElementById('main8').style.display="none"
    	document.getElementById('main9').style.display="none"
    break;
  case 'sub3': 
	document.getElementById('main1').style.display="none"
	document.getElementById('main2').style.display="none"
	document.getElementById('main4').style.display="none"
	document.getElementById('main5').style.display="none"
	document.getElementById('main6').style.display="none"
	document.getElementById('main7').style.display="none"
	document.getElementById('main8').style.display="none"
    	document.getElementById('main9').style.display="none"
  break;
  case 'sub4': 
	document.getElementById('main1').style.display="none"
	document.getElementById('main2').style.display="none"
	document.getElementById('main3').style.display="none"
	document.getElementById('main5').style.display="none"
	document.getElementById('main6').style.display="none"
	document.getElementById('main7').style.display="none"
	document.getElementById('main8').style.display="none"
    	document.getElementById('main9').style.display="none"
		
  break;
  case 'sub5': 
	document.getElementById('main1').style.display="none"
	document.getElementById('main2').style.display="none"
	document.getElementById('main3').style.display="none"
	document.getElementById('main4').style.display="none"
	document.getElementById('main6').style.display="none"
	document.getElementById('main7').style.display="none"
	document.getElementById('main8').style.display="none"
    	document.getElementById('main9').style.display="none"

  break;
  case 'sub6': 
	document.getElementById('main1').style.display="none"
	document.getElementById('main2').style.display="none"
	document.getElementById('main3').style.display="none"
	document.getElementById('main4').style.display="none"
	document.getElementById('main5').style.display="none"
	document.getElementById('main7').style.display="none"
	document.getElementById('main8').style.display="none"
    	document.getElementById('main9').style.display="none"

  break;
  case 'sub7': 
	document.getElementById('main1').style.display="none"
	document.getElementById('main2').style.display="none"
	document.getElementById('main3').style.display="none"
	document.getElementById('main4').style.display="none"
	document.getElementById('main5').style.display="none"
	document.getElementById('main6').style.display="none"
	document.getElementById('main8').style.display="none"
    	document.getElementById('main9').style.display="none"

  break;
case 'sub8': 
	document.getElementById('main1').style.display="none"
	document.getElementById('main2').style.display="none"
	document.getElementById('main3').style.display="none"
	document.getElementById('main4').style.display="none"
	document.getElementById('main5').style.display="none"
	document.getElementById('main6').style.display="none"
	document.getElementById('main7').style.display="none"
    	document.getElementById('main9').style.display="none"

  break;
case 'sub9': 
	document.getElementById('main1').style.display="none"
	document.getElementById('main2').style.display="none"
	document.getElementById('main3').style.display="none"
	document.getElementById('main4').style.display="none"
	document.getElementById('main5').style.display="none"
	document.getElementById('main6').style.display="none"
	document.getElementById('main7').style.display="none"
    	document.getElementById('main8').style.display="none"

  break;

 default: 
//   document.getElementById(cookievalue).style.display="block"

}
}

function onloadfunctionElite(){
if (persistmenu=="yes"){
var cookiename=(persisttype=="sitewide")? 'setdoorstyle' : window.location.pathname
var cookievalue=get_cookie(cookiename)
//if (cookievalue!="")
//document.getElementById(cookievalue).style.display="block"
}

switch (cookievalue) {
  case 'Classic': 
	document.getElementById('elitemain2').style.display="none"
	document.getElementById('elitemain3').style.display="none"
    break;

  case 'Harmony': 
	document.getElementById('elitemain1').style.display="none"
	document.getElementById('elitemain2').style.display="none"
    break;
   
 default: 
	document.getElementById('elitemain1').style.display="none"
	document.getElementById('elitemain3').style.display="none"
 
}
}

//**828 changes
//1- Add id to menus
//2- use this onloadfunction function 
//3- add in Head for pages in style/sub folders <script type="text/javascript" src="../saberis.js"></script> 
//4- add in Head for pages in style folder <script type="text/javascript" src="saberis.js"></script> 

/**
 * Sets a Cookie with the given name and value.
 *
 * name       Name of the cookie
 * value      Value of the cookie
 * [expires]  Expiration date of the cookie (default: end of current session)
 * [path]     Path where the cookie is valid (default: path of calling document)
 * [domain]   Domain where the cookie is valid
 *              (default: domain of calling document)
 * [secure]   Boolean value indicating if the cookie transmission requires a
 *              secure transmission
 */
function switchmenu828(obj){
	if(document.getElementById){
	var el = document.getElementById(obj);
	var ar = document.getElementById("masterdiv").getElementsByTagName("span"); //DynamicDrive.com change
		if(el.style.display != "block"){ //DynamicDrive.com change
			for (var i=0; i<ar.length; i++){
				if (ar[i].className=="submenu") //DynamicDrive.com change
				ar[i].style.display = "none";
			}
			el.style.display = "block";
		}else{
			el.style.display = "none";
		}
	}
}

function SwitchMenu(obj){
	if(document.getElementById){
	var el = document.getElementById(obj);
	var ar = document.getElementById("masterdiv").getElementsByTagName("span"); //DynamicDrive.com change
		if(el.style.display != "block"){ //DynamicDrive.com change
			for (var i=0; i<ar.length; i++){
				if (ar[i].className=="submenu") //DynamicDrive.com change
				ar[i].style.display = "none";
			}
			el.style.display = "block";
		}else{
			el.style.display = "none";
		}
	}
}


function get_cookie(Name) { 
var search = Name + "="
var returnvalue = "";
if (document.cookie.length > 0) {
offset = document.cookie.indexOf(search)
if (offset != -1) { 
offset += search.length
end = document.cookie.indexOf(";", offset);
if (end == -1) end = document.cookie.length;
returnvalue=unescape(document.cookie.substring(offset, end))
}
}
return returnvalue;
}

function savemenustate(){
var inc=1, blockid=""
while (document.getElementById("sub"+inc)){
if (document.getElementById("sub"+inc).style.display=="block"){
blockid="sub"+inc
break
}
inc++
}
var cookiename=(persisttype=="sitewide")? "switchmenu881" : window.location.pathname
var cookievalue=(persisttype=="sitewide")? blockid+";path=/" : blockid
document.cookie=cookiename+"="+cookievalue
}

function setDoorStyle(){
		var results  =get_cookie('doorstyle');
		setCookie("setdoorstyle",results,'','/' );
}

function setCookie(name, value, expires, path, domain, secure) {
    document.cookie= name + "=" + escape(value) +
        ((expires) ? "; expires=" + expires.toGMTString() : "") +
        ((path) ? "; path=" + path : "") +
        ((domain) ? "; domain=" + domain : "") +
        ((secure) ? "; secure" : "");
        
}


function SaveDoorStyle (selecteddoorstyle){
		setCookie("doorstyle",selecteddoorstyle,'','/') ;
		
}


 
function Save828(selectedfinish){
	setCookie("finish",selectedfinish,'','/') ;
}

function set828(){
	var results  =get_cookie('finish');
		setCookie("setfinish",results,'','/' );	
}
function setarrow881(){
if (persistmenu=="yes"){
var cookiename=(persisttype=="sitewide")? "switchmenu881" : window.location.pathname
var cookievalue=get_cookie(cookiename)
switch (cookievalue) {
  case 'sub1': 
   	document.getElementById('Arrow1').innerHTML ="&#9660";
    break;
  case 'sub2': 
   	document.getElementById('Arrow2').innerHTML ="&#9660";
    break;
  case 'sub3': 
   	document.getElementById('Arrow3').innerHTML ="&#9660";
    break;
  case 'sub4': 
   	document.getElementById('Arrow4').innerHTML ="&#9660";
    break;
  case 'sub5': 
   	document.getElementById('Arrow5').innerHTML ="&#9660";
    break;
  case 'sub6': 
   	document.getElementById('Arrow6').innerHTML ="&#9660";
    break;
  case 'sub7': 
   	document.getElementById('Arrow7').innerHTML ="&#9660";
    break;
 case 'sub8': 
   	document.getElementById('Arrow8').innerHTML ="&#9660";
    break;
case 'sub9': 
   	document.getElementById('Arrow9').innerHTML ="&#9660";
    break;
}
}
}


 function cancel(){
 parent.close();  
}
 

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}


function FP_changeProp() {//v1.0
 var args=arguments,d=document,i,j,id=args[0],o=FP_getObjectByID(id),s,ao,v,x;
 d.$cpe=new Array(); if(o) for(i=2; i<args.length; i+=2) { v=args[i+1]; s="o"; 
 ao=args[i].split("."); for(j=0; j<ao.length; j++) { s+="."+ao[j]; if(null==eval(s)) { 
  s=null; break; } } x=new Object; x.o=o; x.n=new Array(); x.v=new Array();
 x.n[x.n.length]=s; eval("x.v[x.v.length]="+s); d.$cpe[d.$cpe.length]=x;
 if(s) eval(s+"=v"); }
}

function FP_getObjectByID(id,o) {//v1.0
 var c,el,els,f,m,n; if(!o)o=document; if(o.getElementById) el=o.getElementById(id);
 else if(o.layers) c=o.layers; else if(o.all) el=o.all[id]; if(el) return el;
 if(o.id==id || o.name==id) return o; if(o.childNodes) c=o.childNodes; if(c)
 for(n=0; n<c.length; n++) { el=FP_getObjectByID(id,c[n]); if(el) return el; }
 f=o.forms; if(f) for(n=0; n<f.length; n++) { els=f[n].elements;
 for(m=0; m<els.length; m++){ el=FP_getObjectByID(id,els[n]); if(el) return el; } }
 return null;
}

function FP_changePropRestore() {//v1.0
 var d=document,x; if(d.$cpe) { for(i=0; i<d.$cpe.length; i++) { x=d.$cpe[i];
 if(x.v=="") x.v=""; eval("x."+x.n+"=String(x.v)"); } d.$cpe=null; }
}
