// JavaScript Document

var params;

function okButtonClick(id) {
	parent.returnValue=id;
	parent.close();
}

function getParams()
{
	params = document.location.search.substring(1).split('&');
	for (var i=0; i<params.length; i++)
	{
		var param = params[i].split('=');
		params[param[0]] = param[1]; 
	} 
}
