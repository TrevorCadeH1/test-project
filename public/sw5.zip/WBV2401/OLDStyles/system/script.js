var favFolder = location.href.substr(8)
favFolder = favFolder.substr(0,favFolder.lastIndexOf('/'))
var catName = favFolder.substr(0,favFolder.lastIndexOf('/'))
catName = catName.substr(catName.lastIndexOf('/')+1).toUpperCase()
var Conn;

function loadConn()
{
	favFolder = favFolder.replace(/\%20/g, " ");
	Conn = ObjMaster.GenObject("ADODB.Connection")
	Conn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source="+ favFolder +"/system/db_favorites.mdb;Persist Security Info=False"
}

function RemoveFromFavorite(code)
{
	var RS;
	RS = Conn.Execute("SELECT nm_catalog, dc_reckey FROM t_favorite WHERE id_type="+ id_type +" AND nm_catalog='"+ catName +"' AND dc_reckey='"+ code +"'")
	if (!RS.EOF)
	{
		if (confirm('Do you really want to remove this Style from your Favorites?'))
		{
			Conn.Execute ("DELETE FROM t_favorite WHERE id_type="+ id_type +" AND nm_catalog='"+ catName +"' AND dc_reckey='"+ code +"'")
			buildFavorites()
		}
	}
	else
		alert('This style is no longer available in your Favorites.')
}

function buildFavorites()
{
	RS = Conn.Execute("SELECT * FROM t_favorite WHERE id_type="+ id_type +" AND nm_catalog='"+ catName +"' ORDER BY dc_item")
	if (RS.EOF)
		document.all.content.innerHTML='<p></p><p align="center">You do <b>not</b> have any style saved in your Favorites.</p>'
	else
	{
		RS.MoveFirst()
		str = '<table cellspacing="2" vspace="0" hspace="0" align="center">'
		iSide = 0
		do 
		{
			if (iSide==0)
			{
				str += '<tr>'
			}
			desc = '' + RS("dc_usercode")
			str += '<td><table width="125" cellpadding="0" cellspacing="0" border="0"><tr><td align="center" valign="top" class="TDBorder"><input type="image" id="'+ RS("dc_reckey") +'" src="../../Styles/'+ desc +'.jpg" onClick="okButtonClick(id)"></td></tr>\r\n'
			str += '<tr><td height="12"></td></td><tr><td width="100%" align="center" valign="top" bgcolor="#F5DEB3"><font face="Arial" color="#000080" size="-1"><b>'+ RS("dc_item") +'<font size="-2"><br>'+ RS("dc_usercode") +'</b>'
			str += '<p><a href="javascript:RemoveFromFavorite(\''+ RS("dc_reckey") +'\')" title="Remove from Favorites"><font color="red"><B><U>Remove</U></B></font></a></p></td></tr></table></td>'
			if (iSide==2)
			{
				str+='</tr><tr><td height="20"></td></tr>'
				iSide=0;
			}
			else
			{
				str+='<td width="20" align="center" valign="top">&nbsp;</td>'
				iSide++
			}
			RS.MoveNext()
		}
		while (!RS.EOF)
		str +='</table>'
		document.all.content.innerHTML=str
	}
}

function okButtonClick(id)
{
	parent.returnValue=id
	parent.close();
}

function getVarHref (nomVariable)
{
    var infos = location.href.substring(location.href.indexOf("?")+1, location.href.length)+"&";
    if (infos.indexOf("#")!=-1)
	    infos = infos.substring(0,infos.indexOf("#"))+"&";
    var variable=0;
    {
	    nomVariable = nomVariable + "=";
	    var taille = nomVariable.length;
	    if (infos.indexOf(nomVariable)!=-1)
		    variable = infos.substring(infos.indexOf(nomVariable)+taille,infos.length).substring(0,infos.substring(infos.indexOf(nomVariable)+taille,infos.length).indexOf("&"));
    }
    return variable;
}

function SendToFavorite(code,desc,usercode)
{
	var RS;
	RS = Conn.Execute("SELECT nm_catalog, dc_reckey FROM t_favorite WHERE nm_catalog='"+ catName +"' AND dc_reckey='"+ code +"'")
	if (RS.EOF)
	{
		Conn.Execute ("INSERT INTO t_favorite (nm_catalog, dc_reckey, dc_item, dc_usercode, id_type) VALUES('"+ catName +"','"+ code +"','"+ desc +"','"+ usercode +"',"+ id_type +")")
		alert('The style \''+ desc +'\' was added successfully\rto your Favorites styles.')
//		obj = top.document.getElementById('table_troca')
//		alert(obj)
//		obj.left = document.body.clientWidth / 2 - 140
//		obj.top = document.body.clientHeight / 2 - 40
//		obj.style.display='block'
	}
	else
		alert('This item is already present in your Favorites styles.')
}

	loadConn()
	Conn.Open()